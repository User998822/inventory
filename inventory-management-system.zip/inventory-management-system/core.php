<?php 

session_start();

require_once 'db_connect.php';

// echo $_SESSION['userId'];

if(!$_SESSION['userId']) {
	header('location: http://localhost/inventory-management-system/index.php');	
} 



?>
<!DOCTYPE html>
<html>
<head>
    <div>
        <div>
            <p style="text-align: center"> Copyright &copy;<script>document.write(new Date().getFullYear())</script> Created By Rajesh</p>
        </div>
    </div>
</head>
</html>
<head>